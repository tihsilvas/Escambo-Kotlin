package com.etec.apis

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.etec.apis.databinding.ActivityHomeBinding
import com.google.firebase.auth.FirebaseAuth

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d("HomeActivity", "HomeActivity iniciada")

        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        // Configura a Toolbar
        setSupportActionBar(binding.toolbar)

        // Recupera o nome do usuário passado pelo Intent
        val userName = intent.getStringExtra("USER_NAME") ?: "Usuário"
        supportActionBar?.title = "Bem-vindo, $userName" // Atualiza o título da Toolbar

        // Forçar a exibição de um fragmento específico para teste
        loadFragment(AdicionarLivroFragment())  // Exibe o HomeFragment de forma forçada

        // Configura a navegação no BottomNavigation com setOnItemSelectedListener
        binding.bottomNavigation.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    loadFragment(AdicionarLivroFragment())  // Carrega o HomeFragment
                    true
                }
                R.id.nav_pesquisar -> {
                    loadFragment(PesquisaLivroFragment())  // Carrega o PesquisaLivroFragment
                    true
                }
                R.id.nav_perfil -> {
                    loadFragment(PerfilFragment())  // Carrega o PerfilFragment
                    true
                }
                else -> false
            }
        }
    }

    // Método para carregar o fragmento na tela
    private fun loadFragment(fragment: Fragment) {
        Log.d("HomeActivity", "Tentando carregar o fragment: ${fragment::class.java.simpleName}")
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commitNow()  // Commit imediato
    }

    // Função para realizar o logout
    private fun logout() {
        auth.signOut() // Faz o logout do usuário
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish() // Finaliza a HomeActivity
    }
}
