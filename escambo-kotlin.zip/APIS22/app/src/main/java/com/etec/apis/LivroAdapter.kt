package com.etec.apis

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.etec.apis.databinding.ItemLivroBinding
import com.google.firebase.firestore.FirebaseFirestore

class LivroAdapter : ListAdapter<Livro, LivroAdapter.LivroViewHolder>(LivroDiffCallback()) {

    private val db = FirebaseFirestore.getInstance()

    // Callback para notificar sobre a exclusão do livro
    var onLivroExcluido: ((Livro) -> Unit)? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LivroViewHolder {
        val binding = ItemLivroBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return LivroViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LivroViewHolder, position: Int) {
        val livro = getItem(position)
        holder.bind(livro)
    }

    inner class LivroViewHolder(private val binding: ItemLivroBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(livro: Livro) {
            // Definir os dados nos TextViews
            binding.nomeLivro.text = livro.nome  // Nome do Livro
            binding.usuarioAdicionador.text = livro.usuarioNome  // Nome do Usuário

            // Configurar o botão de escambo
            binding.botaoEscambo.setOnClickListener {
                val context = binding.root.context
                val intent = when (context) {
                    is SelecaoLivrosActivity -> {
                        // Se o contexto for SelecaoLivrosActivity, exclui o livro e vai para ActivityTrocaSucesso
                        excluirLivro(livro)
                        val intent = Intent(context, ActivityTrocaSucesso::class.java)
                        intent.putExtra("livro_nome", livro.nome) // Passa o nome do livro
                        context.startActivity(intent)
                        null  // Não precisamos navegar para outra activity aqui, pois já fizemos isso
                    }
                    else -> {
                        // Se não for SelecaoLivrosActivity, apenas vai para SelecaoLivrosActivity
                        val intent = Intent(context, SelecaoLivrosActivity::class.java)
                        context.startActivity(intent)
                        null
                    }
                }
                // Se o intent não for nulo, inicia a navegação
                intent?.let { context.startActivity(it) }
            }
        }

        private fun excluirLivro(livro: Livro) {
            val livroId = livro.id // Supondo que o livro tenha um ID no Firestore
            livroId?.let {
                db.collection("livros").document(it).delete()
                    .addOnSuccessListener {
                        // Não exibe mais o Toast de sucesso
                        // Aqui você pode apenas chamar o callback para atualizar a interface se necessário
                        onLivroExcluido?.invoke(livro)
                    }
                    .addOnFailureListener { e ->
                        // Não exibe mais o Toast de erro
                        // Aqui você pode registrar o erro no Log, mas sem notificar o usuário
                        Log.e("ExcluirLivro", "Erro ao excluir livro: ${e.message}", e)
                    }
            }
        }

    }
}

data class Livro(val nome: String, val usuarioNome: String, val id: String? = null)
