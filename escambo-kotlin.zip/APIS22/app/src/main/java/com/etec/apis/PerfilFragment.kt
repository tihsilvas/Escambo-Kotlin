package com.etec.apis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.etec.apis.databinding.FragmentPerfilBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class PerfilFragment : Fragment() {

    private lateinit var binding: FragmentPerfilBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inicializar o binding
        binding = FragmentPerfilBinding.inflate(inflater, container, false)

        // Obter a instância do FirebaseAuth e Firestore
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Verifica se o usuário está logado
        val user = auth.currentUser
        if (user != null) {
            // Busca o nome do usuário no Firestore usando o UID
            val userDocRef = firestore.collection("users").document(user.uid)

            userDocRef.get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        val userName = document.getString("name") // O campo 'name' no Firestore
                        binding.tvUserName.text = userName ?: "Nome não disponível"
                    } else {
                        binding.tvUserName.text = "Nome não encontrado"
                    }
                }
                .addOnFailureListener { exception ->
                    Log.w("PerfilFragment", "Erro ao obter o nome do usuário", exception)
                    binding.tvUserName.text = "Erro ao carregar nome"
                }

            // Exibe o e-mail
            binding.tvUserEmail.text = user.email ?: "Email não disponível"
        } else {
            // Caso o usuário não esteja logado
            binding.tvUserName.text = "Usuário não logado"
            binding.tvUserEmail.text = "Por favor, faça login para ver as informações."
        }

        // Configura o botão de logout
        binding.btnLogout.setOnClickListener {
            //logout()
            var saida = Intent(context , MainActivity::class.java)
            startActivity(saida)
        }

        return binding.root
    }

    // Função para realizar o logout
    private fun logout() {
        auth.signOut() // Faz o logout do usuário

        // Finaliza a activity ou navega para a tela de login (dependendo de como for a navegação)
        activity?.finish() // Exemplo de encerramento da activity

    }
}
