package com.etec.apis

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignUpActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signUpButton: Button
    private lateinit var errorMessage: TextView
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_sign_up)

        // Inicializa os componentes da UI
        nameEditText = findViewById(R.id.nameEditText)
        emailEditText = findViewById(R.id.email) // Verifique se o ID é "email"
        passwordEditText = findViewById(R.id.password) // Verifique se o ID é "password"
        signUpButton = findViewById(R.id.signUpButton)
        errorMessage = findViewById(R.id.errorMessage)

        // Inicializa o FirebaseAuth e Firestore
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Configura o clique do botão de cadastro
        signUpButton.setOnClickListener {
            signUp()
        }

        // Ajusta o padding para sistemas de barras
        val mainView = findViewById<View>(R.id.signUpLayout)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inicialmente, oculta a mensagem de erro
        errorMessage.visibility = View.GONE
    }

    private fun signUp() {
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        // Valida os campos
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            errorMessage.text = "Preencha todos os campos."
            errorMessage.visibility = View.VISIBLE
            return
        }

        // Tenta criar uma nova conta com email e senha
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Cadastro bem-sucedido, armazena o nome no Firestore
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        val user = hashMapOf(
                            "name" to name,
                            "email" to email
                        )
                        firestore.collection("users").document(userId)
                            .set(user)
                            .addOnSuccessListener {
                                // Redireciona para a HomeActivity
                                val intent = Intent(this, HomeActivity::class.java).apply {
                                    putExtra("USER_NAME", name)
                                }
                                startActivity(intent)
                                finish() // Apenas uma vez
                            }
                            .addOnFailureListener { e ->
                                errorMessage.text = "Erro ao salvar dados. Tente novamente."
                                errorMessage.visibility = View.VISIBLE
                            }
                    }
                } else {
                    // Exibe mensagem de erro
                    errorMessage.text = "Erro ao cadastrar. Verifique suas credenciais."
                    errorMessage.visibility = View.VISIBLE
                }
            }
    }
}
