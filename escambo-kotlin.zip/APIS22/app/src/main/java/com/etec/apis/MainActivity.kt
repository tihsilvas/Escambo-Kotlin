package com.etec.apis

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.etec.apis.databinding.ActivityMainBinding
import android.transition.TransitionManager


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializa a UI
        initUI()
    }

    private fun initUI() {
        // Configura o clique do botão de login
        binding.loginButton.setOnClickListener {
            navigateToLogin()
        }

    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        TransitionManager.beginDelayedTransition(binding.root)
        startActivity(intent)
    }

    private fun navigateToCadastro() {
        val intent = Intent(this, SignUpActivity::class.java)
        TransitionManager.beginDelayedTransition(binding.root)
        startActivity(intent)
    }

}
