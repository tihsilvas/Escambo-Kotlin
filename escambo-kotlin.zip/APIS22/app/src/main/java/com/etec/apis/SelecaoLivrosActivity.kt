package com.etec.apis

import android.os.Bundle
import android.widget.Toast
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.etec.apis.databinding.ActivitySelecaoLivrosBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SelecaoLivrosActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySelecaoLivrosBinding
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private lateinit var livroAdapter: LivroAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySelecaoLivrosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configuração do RecyclerView
        binding.recyclerViewLivros.layoutManager = LinearLayoutManager(this)

        // Inicializar o adapter
        livroAdapter = LivroAdapter()
        livroAdapter.onLivroExcluido = { livro ->
            // Atualiza a lista de livros após a exclusão
            carregarLivros()
        }
        binding.recyclerViewLivros.adapter = livroAdapter

        carregarLivros() // Carregar os livros do usuário autenticado
    }

    private fun carregarLivros() {
        // Obter o ID do usuário autenticado
        val usuarioId = auth.currentUser?.uid
        if (usuarioId == null) {
            Toast.makeText(this, "Usuário não autenticado", Toast.LENGTH_SHORT).show()
            return
        }

        // Consultar os livros do usuário autenticado na coleção "livros"
        db.collection("livros")
            .whereEqualTo("userId", usuarioId) // Filtro para buscar apenas os livros do usuário
            .get()
            .addOnSuccessListener { result ->
                val livros = mutableListOf<Livro>()
                var completedQueries = 0 // Contador para acompanhar as consultas feitas

                // Número total de livros a serem processados
                val totalLivros = result.size()

                for (document in result) {
                    val nomeLivro = document.getString("nome-livro") ?: "Desconhecido"
                    val livroId = document.id // ID do livro no Firestore

                    Log.d("SelecaoLivrosActivity", "Livro: $nomeLivro, Usuário ID: $usuarioId")

                    if (usuarioId != null) {
                        // Consulta o nome do usuário com base no usuarioId
                        db.collection("users").document(usuarioId).get()
                            .addOnSuccessListener { userDocument ->
                                if (userDocument.exists()) {
                                    val usuarioNome = userDocument.getString("name") ?: "Nome não encontrado"
                                    Log.d("SelecaoLivrosActivity", "Nome do usuário encontrado: $usuarioNome")
                                    val livro = Livro(nomeLivro, usuarioNome, livroId)
                                    livros.add(livro)
                                } else {
                                    Log.w("SelecaoLivrosActivity", "Usuário não encontrado para ID: $usuarioId")
                                    livros.add(Livro(nomeLivro, "Nome não encontrado", livroId))
                                }

                                completedQueries++

                                // Verifica se todas as consultas foram concluídas
                                if (completedQueries == totalLivros) {
                                    livroAdapter.submitList(livros) // Atualiza a lista de livros
                                }
                            }
                            .addOnFailureListener { exception ->
                                Log.w("SelecaoLivrosActivity", "Erro ao recuperar nome do usuário", exception)
                                livros.add(Livro(nomeLivro, "Erro ao carregar nome", livroId))
                                completedQueries++

                                // Verifica se todas as consultas foram concluídas
                                if (completedQueries == totalLivros) {
                                    livroAdapter.submitList(livros) // Atualiza a lista de livros
                                }
                            }
                    }
                }

                // Caso não haja livros, ainda assim chama o submitList
                if (totalLivros == 0) {
                    livroAdapter.submitList(livros)
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Erro ao carregar livros: ${e.message}", Toast.LENGTH_LONG).show()
                Log.w("SelecaoLivrosActivity", "Erro ao carregar livros", e)
            }
    }
}
