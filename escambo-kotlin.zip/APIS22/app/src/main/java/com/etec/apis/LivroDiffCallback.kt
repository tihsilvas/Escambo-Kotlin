package com.etec.apis

import androidx.recyclerview.widget.DiffUtil

class LivroDiffCallback : DiffUtil.ItemCallback<Livro>() {

    // Verifica se os itens são os mesmos (baseado no ID do livro)
    override fun areItemsTheSame(oldItem: Livro, newItem: Livro): Boolean {
        return oldItem.id == newItem.id // O id do livro deve ser único
    }

    // Verifica se o conteúdo dos itens é igual
    override fun areContentsTheSame(oldItem: Livro, newItem: Livro): Boolean {
        return oldItem == newItem // Compara todo o conteúdo do objeto Livro
    }
}
