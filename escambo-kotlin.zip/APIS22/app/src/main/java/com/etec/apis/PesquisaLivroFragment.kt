package com.etec.apis

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.firestore.FirebaseFirestore
import com.etec.apis.databinding.FragmentPesquisaLivrosBinding
import com.google.firebase.auth.FirebaseAuth

class PesquisaLivroFragment : Fragment() {

    private var _binding: FragmentPesquisaLivrosBinding? = null
    private val binding get() = _binding!!

    private lateinit var livroAdapter: LivroAdapter
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPesquisaLivrosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Configuração do RecyclerView
        binding.recyclerViewLivros.layoutManager = LinearLayoutManager(requireContext())

        // Configurar o adapter
        livroAdapter = LivroAdapter()
        binding.recyclerViewLivros.adapter = livroAdapter

        carregarLivros() // Carregar todos os livros da Firestore, excluindo os do próprio usuário
    }

    private fun carregarLivros() {
        val usuarioId = auth.currentUser?.uid
        if (usuarioId == null) {
            Toast.makeText(requireContext(), "Usuário não autenticado", Toast.LENGTH_SHORT).show()
            return
        }

        // Consultar todos os livros na coleção "livros", excluindo os do próprio usuário
        db.collection("livros")
            .whereNotEqualTo("userId", usuarioId) // Excluir livros do próprio usuário
            .get()
            .addOnSuccessListener { result ->
                val livros = mutableListOf<Livro>()
                var completedQueries = 0 // Contador para acompanhar as consultas feitas

                val totalLivros = result.size()

                for (document in result) {
                    val nomeLivro = document.getString("nome-livro") ?: "Desconhecido"
                    val usuarioId = document.getString("userId") // ID do usuário que adicionou o livro

                    Log.d("PesquisaLivroFragment", "Livro: $nomeLivro, Usuário ID: $usuarioId")

                    if (usuarioId != null) {
                        // Consulta o nome do usuário com base no usuarioId
                        db.collection("users").document(usuarioId).get()
                            .addOnSuccessListener { userDocument ->
                                if (userDocument.exists()) {
                                    val usuarioNome = userDocument.getString("name") ?: "Nome não encontrado"
                                    Log.d("PesquisaLivroFragment", "Nome do usuário encontrado: $usuarioNome")
                                    val livro = Livro(nomeLivro, usuarioNome)
                                    livros.add(livro)
                                } else {
                                    Log.w("PesquisaLivroFragment", "Usuário não encontrado para ID: $usuarioId")
                                    livros.add(Livro(nomeLivro, "Nome não encontrado"))
                                }

                                completedQueries++

                                // Verifica se todas as consultas foram concluídas
                                if (completedQueries == totalLivros) {
                                    livroAdapter.submitList(livros) // Atualiza a lista de livros
                                }
                            }
                            .addOnFailureListener { exception ->
                                Log.w("PesquisaLivroFragment", "Erro ao recuperar nome do usuário", exception)
                                livros.add(Livro(nomeLivro, "Erro ao carregar nome"))
                                completedQueries++

                                // Verifica se todas as consultas foram concluídas
                                if (completedQueries == totalLivros) {
                                    livroAdapter.submitList(livros) // Atualiza a lista de livros
                                }
                            }
                    } else {
                        // Caso não haja usuarioId, adiciona o livro com nome "Desconhecido"
                        Log.d("PesquisaLivroFragment", "ID de usuário não encontrado para o livro: $nomeLivro")
                        livros.add(Livro(nomeLivro, "Desconhecido"))
                        completedQueries++

                        // Verifica se todas as consultas foram concluídas
                        if (completedQueries == totalLivros) {
                            livroAdapter.submitList(livros) // Atualiza a lista de livros
                        }
                    }
                }

                // Caso não haja livros, ainda assim chama o submitList
                if (totalLivros == 0) {
                    livroAdapter.submitList(livros)
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Erro ao carregar livros: ${e.message}", Toast.LENGTH_LONG).show()
                Log.w("PesquisaLivroFragment", "Erro ao carregar livros", e)
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
