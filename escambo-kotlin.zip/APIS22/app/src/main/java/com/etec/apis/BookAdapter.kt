package com.etec.apis

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.etec.apis.databinding.ListItemBookBinding

// Adapter para exibir os livros no RecyclerView
class BookAdapter(
    private val bookList: MutableList<Book>, // Lista mutável para que possamos remover itens
    private val onDeleteBook: (String) -> Unit // Função para exclusão do livro
) : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    // Cria o ViewHolder e infla o layout de cada item da lista
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val binding = ListItemBookBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BookViewHolder(binding)
    }

    // Preenche o ViewHolder com os dados do livro
    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val book = bookList[position]
        holder.bind(book)
    }

    // Retorna a quantidade de itens na lista
    override fun getItemCount(): Int = bookList.size

    // ViewHolder que segura a referência para o layout do item da lista
    inner class BookViewHolder(private val binding: ListItemBookBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(book: Book) {
            binding.textViewTitle.text = book.title
            // Configura o clique no botão de exclusão
            binding.buttonDelete.setOnClickListener {
                onDeleteBook(book.id) // Passa o id do livro para a função de exclusão
            }
        }
    }
}

// Data class para representar um livro
data class Book(
    val author: String,
    val title: String,
    val genre: String,
    val id: String // Adicionando o ID do livro para exclusão
)
