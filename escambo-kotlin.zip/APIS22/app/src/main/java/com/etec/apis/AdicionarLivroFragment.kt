package com.etec.apis

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.etec.apis.databinding.FragmentAdicionarLivroBinding

class AdicionarLivroFragment : Fragment() {

    private var _binding: FragmentAdicionarLivroBinding? = null
    private val binding get() = _binding!! // Acesso ao binding
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance() // Instância do Firebase Authentication
    private lateinit var bookAdapter: BookAdapter
    private val bookList = mutableListOf<Book>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflar o layout e configurar o binding
        _binding = FragmentAdicionarLivroBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Configuração do RecyclerView
        bookAdapter = BookAdapter(bookList, ::onDeleteBook) // Passa a função de exclusão para o adapter
        binding.recyclerViewBooks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewBooks.adapter = bookAdapter

        // Carregar livros do Firestore
        carregarLivros()

        binding.buttonAddBook.setOnClickListener {
            val autor = binding.editTextAuthor.text.toString().trim()
            val nome = binding.editTextTitle.text.toString().trim()
            val genero = binding.editTextGenre.text.toString().trim()

            if (autor.isNotEmpty() && nome.isNotEmpty() && genero.isNotEmpty()) {
                adicionarLivro(autor, nome, genero)
            } else {
                Toast.makeText(requireContext(), "Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun carregarLivros() {
        val userId = auth.currentUser?.uid // Pega o UID do usuário logado

        // Verifique se o usuário está logado
        if (userId != null) {
            // Filtra os livros pelo userId
            db.collection("livros")
                .whereEqualTo("userId", userId) // Filtra apenas livros do usuário logado
                .get()
                .addOnSuccessListener { result ->
                    bookList.clear() // Limpar a lista antes de adicionar novos itens
                    for (document in result) {
                        val autor = document.getString("autor-livro") ?: ""
                        val nome = document.getString("nome-livro") ?: ""
                        val genero = document.getString("genero-livro") ?: ""
                        val livro = Book(autor, nome, genero, document.id) // Inclui o id do documento para excluir
                        bookList.add(livro)
                    }
                    bookAdapter.notifyDataSetChanged() // Atualizar a lista
                }
                .addOnFailureListener { e ->
                    Toast.makeText(requireContext(), "Erro ao carregar livros: ${e.message}", Toast.LENGTH_LONG).show()
                }
        } else {
            Toast.makeText(requireContext(), "Usuário não está logado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun adicionarLivro(autor: String, nome: String, genero: String) {
        val userId = auth.currentUser?.uid // Pega o UID do usuário logado

        if (userId != null) {
            val livro = hashMapOf(
                "autor-livro" to autor,
                "nome-livro" to nome,
                "genero-livro" to genero,
                "userId" to userId // Adiciona o userId ao livro
            )

            db.collection("livros")
                .add(livro)
                .addOnSuccessListener {
                    Toast.makeText(requireContext(), "Livro adicionado com sucesso!", Toast.LENGTH_SHORT).show()
                    // Limpar os campos após o sucesso
                    binding.editTextAuthor.text.clear()
                    binding.editTextTitle.text.clear()
                    binding.editTextGenre.text.clear()
                    carregarLivros() // Recarregar a lista de livros
                }
                .addOnFailureListener { e ->
                    Toast.makeText(requireContext(), "Erro ao adicionar livro: ${e.message}", Toast.LENGTH_LONG).show()
                }
        } else {
            Toast.makeText(requireContext(), "Usuário não está logado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun excluirLivro(bookId: String) {
        db.collection("livros").document(bookId)
            .delete()
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Livro excluído com sucesso", Toast.LENGTH_SHORT).show()
                carregarLivros() // Recarregar a lista após a exclusão
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Erro ao excluir livro: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    // Função chamada pelo Adapter para deletar um livro
    private fun onDeleteBook(bookId: String) {
        excluirLivro(bookId)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null // Limpar o binding para evitar vazamento de memória
    }
}
