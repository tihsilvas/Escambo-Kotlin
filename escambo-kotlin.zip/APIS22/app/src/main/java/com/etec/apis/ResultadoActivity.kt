package com.etec.apis

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.etec.apis.databinding.ActivityResultadoBinding

class ResultadoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResultadoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializa o ViewBinding
        binding = ActivityResultadoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Recuperando os dados passados pela PesquisaLivroActivity
        val nomeLivro = intent.getStringExtra("nome-livro")
        val autorLivro = intent.getStringExtra("autor-livro")
        val generoLivro = intent.getStringExtra("genero-livro")

        // Atualizando os TextViews com os dados
        binding.textLivro.text = nomeLivro ?: "Nome não encontrado"
        binding.textLivroAutor.text = autorLivro ?: "Autor não encontrado"
        binding.textLivroGenero.text = generoLivro ?: "Gênero não encontrado"
    }
}
